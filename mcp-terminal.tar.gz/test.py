print("MCP client working in the device")
